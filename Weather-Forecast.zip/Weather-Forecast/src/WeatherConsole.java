import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


/**
 * 
 */

/**
 * @author CMPFKHAL
 *
 */
public class WeatherConsole {

	/**
	 * @param args
	 */
	
		// TODO Auto-generated method stub
		private static Scanner input = new Scanner(System.in);
		static ArrayList<WeatherConditions> room = new ArrayList<WeatherConditions>();

		private final static String USER_AGENT = "Mozilla/5.0";
		
		public static void main(String[] args) throws Exception {
			homePage();
		
			String choice = " ";
			do {
				System.out.println("\n--Weather_system --");
				System.out.println("1 -Seach for location");
				System.out.println("2 -View Full report");
				System.out.println("3 -Help");
				System.out.println("Q -Quit");
				System.out.print("Pick : ");
				
	            // User input choice
				choice = input.next().toUpperCase();

				switch (choice) {
				case "1": {
					Location();
					break;
				}
				case "2": {
					Viewreport();
					break;
				}
				case "3": {
					Help();
					break;
				}

				}

			} while (!choice.equals("Q"));
			System.out.println("---GOOD BYE----");
		}

		private static void homePage() {
			// TODO Auto-generated method stub
			
		}

		private static void Location() throws Exception {
			System.out.println("-----Search Specific Location-----");
			System.out.println("\nPlease enter the name of the location you would like to search for.");
			String location=input.next();
		String url = "http://datapoint.metoffice.gov.uk/public/data/val/wxfcs/all/json/3840?res=3hourly&key=4e042427-0da5-4d62-906e-51797de931b9";
		//	String url = "http://api.openweathermap.org/data/2.5/weather?q=London,uk&APPID=da92ea39d19f344e8c93b1a83f03027f";
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			// optional default is GET
						con.setRequestMethod("GET");

						//add request header
						con.setRequestProperty("User-Agent", USER_AGENT);

						int responseCode = con.getResponseCode();
					//	System.out.println("\nSending 'GET' request to URL : " + url);
					//	System.out.println("Response Code : " + responseCode);

						BufferedReader in = new BufferedReader(
						        new InputStreamReader(con.getInputStream()));
						String inputLine;
						StringBuffer response = new StringBuffer();

						while ((inputLine = in.readLine()) != null) {
							response.append(inputLine);
						}
						in.close();

						//print result
					System.out.println(response.toString());

						JSONObject obj1 = new JSONObject(response.toString());
					/*	String description = obj1.getJSONArray("weather").getJSONObject(0).getString("description");
				        float temperature = obj1.getJSONObject("main").getFloat("temp");
				// String description = obj1.getJSONArray("weather").getJSONObject(0).getString("description");
				        String main = obj1.getJSONArray("weather").getJSONObject(0).getString("main");
				        int pressure = obj1.getJSONObject("main").getInt("pressure");
				        int humidity = obj1.getJSONObject("main").getInt("humidity");
				    //	String icon = obj1.getJSONArray("weather").getJSONObject(0).getString("icon");
				        double maxtemp = obj1.getJSONObject("main").getDouble("temp_max");
				        double  mintemp =obj1.getJSONObject("main").getDouble("temp_min");
				        int visi =obj1.getInt("visibility");
				        double  wind =obj1.getJSONObject("wind").getDouble("speed");
				        int  direc =obj1.getJSONObject("wind").getInt("deg");*/
						String name = obj1.getJSONArray("Param").getJSONObject(0).getString("$");
				        System.out.println("Weather:"+name);
				        //Weather
				    /*   System.out.println("Weather:"+main);
				       //System.out.println("Icon:"+icon);
				       System.out.println("Description:"+description);
				       //Temperature and pressure
				       System.out.println("Temperature:"+temperature);
				       System.out.println("Max_Temp:"+maxtemp);
				       System.out.println("Min_Temp:"+mintemp);
				       System.out.println("Pressure:"+pressure);
				       System.out.println("Humidity:"+humidity);
				  // Visibility
				       System.out.println("Visibility:"+visi);
				       //Wind speed and direction
				       System.out.println("Windspeed:"+wind);
				       System.out.println("Direction:"+direc);
				      
				        */
			
			
			}
		
		
		private static void Viewreport() {
			System.out.println("-----View Full Weather Report-----");
		}

		private static void Help() {
			System.out.println("-----Help-----");
			System.out.println("\nWelcome to the program. in order to use the app please read the options you are provided with \nand then choose a number to preform the function you would like to see, then press enter to \nconfirm your choice");
			System.out.println("\nPlease press enter to get back to the main menu");
			try {
				System.in.read();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			homePage();
						
				}
}


