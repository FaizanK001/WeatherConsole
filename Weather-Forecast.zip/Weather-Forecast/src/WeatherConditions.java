
public class WeatherConditions {

	private int Date;
	private int Time;
	private String Location;
	private String weathertype;
	private double Temperature;
	private double Windspeed,WindDi;
	private String searchLocation;
	
public WeatherConditions (int Date, int Time,String Location , String weathertype, double Temperature, double Windspeed, double WindDi, String searchLocation) {
	
this.Date= Date;
this.Location= Location;
this.Time= Time;
this.weathertype= weathertype;
this.Temperature = Temperature;
this.WindDi= WindDi;
this.Windspeed=Windspeed;
this.searchLocation = searchLocation;



	
}
public String toString() {
	String result= Date + "  " + Time + " " + Location+ " " + weathertype + "  " + Temperature+"  " + Windspeed+" "+ WindDi+" ";
	return result;
}

public boolean isFree()
{
	return "free".equals(this.searchLocation);
}
public int getDate() {
	return Date;
}
public void setDate(int date) {
	Date = date;
}
public int getTime() {
	return Time;
}
public void setTime(int time) {
	Time = time;
}
public String getLocation() {
	return Location;
}
public void setLocation(String location) {
	Location = location;
}
public String getWeathertype() {
	return weathertype;
}
public void setWeathertype(String weathertype) {
	this.weathertype = weathertype;
}
public double getTemperature() {
	return Temperature;
}
public void setTemperature(double temperature) {
	Temperature = temperature;
}
public double getWindspeed() {
	return Windspeed;
}
public void setWindspeed(double windspeed) {
	Windspeed = windspeed;
}
public double getWindDi() {
	return WindDi;
}
public void setWindDi(double windDi) {
	WindDi = windDi;
}
public String getSearchLocation() {
	return searchLocation;
}
public void setSearchLocation(String searchLocation) {
	this.searchLocation = searchLocation;
}


}
